<?php
/** По делу v1.5.0. Общая оболочка. */
if(!defined('B_PROLOG_INCLUDED')||B_PROLOG_INCLUDED!==true){die();}
\Bitrix\Main\UI\Extension::load('main.core');\Bitrix\Main\Page\Asset::getInstance()->addCss(SITE_TEMPLATE_PATH.'/app.css?v=1.5.0');
?><!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title><?php $APPLICATION->ShowTitle(); ?></title><?php $APPLICATION->ShowHead(); ?></head><body><?php $APPLICATION->ShowPanel(); ?><header class="header"><a href="/clients/" class="brand"><i></i><span>ПО ДЕЛУ <small>by Markitan Concept</small></span></a><span class="header-meta">РАБОЧЕЕ ПРОСТРАНСТВО / v1.5.0</span></header>
