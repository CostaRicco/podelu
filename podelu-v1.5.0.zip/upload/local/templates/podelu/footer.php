<?php
/** По делу v1.5.0. */
if(!defined('B_PROLOG_INCLUDED')||B_PROLOG_INCLUDED!==true){die();}
?><footer class="footer"><span>ПО ДЕЛУ / MARKITAN CONCEPT</span><span>v1.5.0 · BITRIX EDITION</span></footer></body></html>
