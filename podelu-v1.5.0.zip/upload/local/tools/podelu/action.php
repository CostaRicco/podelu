<?php
/** По делу v1.5.0. Единственный POST-обработчик. Вход, IsAdmin, CSRF, PRG.
 * Выполняется до вывода HTML. Не принимает адреса других сайтов для перенаправления. */
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php';
use Markitan\Podelu\Repository;use Markitan\Podelu\Validation as V;
require_once $_SERVER['DOCUMENT_ROOT'].'/local/components/markitan/podelu/lib/Repository.php';require_once $_SERVER['DOCUMENT_ROOT'].'/local/components/markitan/podelu/lib/Validation.php';
header('Cache-Control: no-store, private');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);header('Allow: POST');exit('POST required');}
if(!$USER->IsAuthorized()||!$USER->IsAdmin()){http_response_code(403);exit('Access denied');}
if(!check_bitrix_sessid()){http_response_code(403);exit('CSRF/session expired. Reload the form.');}
$p=$_POST;$get=static function($k,$default='')use($p){return $p[$k]??$default;};$return=V::localUrl($get('return','/clients/'));$success=$return;$action=$get('action');
try{
 $r=new Repository();$r->ready();$u=(int)$USER->GetID();$id=V::id($get('id','0'),true);$client=V::id($get('client','0'),true);
 switch($action){
  case 'client':$name=V::text($get('name'),150,true);$site=V::text($get('site'),255);if($site!==''){if(strpos($site,'://')===false)$site='https://'.$site;$parsed=parse_url($site);if(!$parsed||!in_array(strtolower($parsed['scheme']??''),['http','https'],true)||empty($parsed['host'])||isset($parsed['user'])||isset($parsed['pass'])||preg_match('/\s/u',$site)||mb_strlen($site)>255)throw new InvalidArgumentException('Некорректный адрес сайта.');}$new=$r->addClient($name,$site,V::text($get('note'),3000),$get('active')==='Y',$u);$success='/clients/detail.php?client='.$new.'&tab=data';break;
  case 'direction':$r->addDirection(V::text($get('name'),100,true));$success='/settings/';break;
  case 'package':$dirs=$get('directions',[]);if(!is_array($dirs)||count($dirs)<1||count($dirs)>50)throw new InvalidArgumentException('Выберите от 1 до 50 направлений.');$list=[];foreach($dirs as $d)$list[]=V::id($d);$m=V::month($get('month'));$r->savePackage($id,V::id($client),$m,V::text($get('name'),150,true),V::minutes($get('hours')),array_values(array_unique($list)),$get('repeat')==='Y',V::month($get('end'),true),V::choice($get('scope','one'),['one','from']),$u);$success='/clients/detail.php?client='.$client.'&tab=packages&month='.$m;break;
  case 'end':$r->end(V::id($id),V::id($client),V::month($get('end'),true));$success='/clients/detail.php?client='.$client.'&tab=packages&month='.V::month($get('month'));break;
  case 'manage':$mode=V::choice($get('mode'),['finish','skip','restore','delete','clear']);if($mode==='delete'&&V::text($get('confirm'),30)!=='УДАЛИТЬ')throw new InvalidArgumentException('Для полного удаления введите УДАЛИТЬ.');$r->manage(V::id($id),V::id($client),V::month($get('month')),$mode);break;
  case 'task':$m=V::month($get('month'));$r->saveTask($id,V::id($client),V::text($get('name'),180,true),V::text($get('description'),5000),V::text($get('note'),5000),V::id($get('direction')),V::choice($get('status'),['planned','work','done']),$m,$u);$success='/clients/detail.php?client='.$client.'&tab=works&month='.$m;break;
  case 'deleteTask':$r->deleteTask(V::id($id),V::id($client));$success='/clients/detail.php?client='.$client.'&tab=works&month='.V::month($get('month'));break;
  case 'time':$date=V::date($get('date'));$token=V::text($get('request'),32,true);if(!preg_match('/^[a-f0-9]{32}$/',$token))throw new InvalidArgumentException('Обновите форму записи времени.');$r->saveTime($id,V::id($client),V::id($get('task')),V::id($get('package','0'),true),$date,V::minutes($get('hours'),true),V::text($get('description'),3000),$u,$token);$success='/clients/detail.php?client='.$client.'&tab=works&month='.substr($date,0,7);break;
  case 'deleteTime':$r->deleteTime(V::id($id),V::id($client));$success='/clients/detail.php?client='.$client.'&tab=works&month='.V::month($get('month'));break;
  default:throw new InvalidArgumentException('Неизвестное действие.');
 }
 $_SESSION['MC_PODELU_FLASH']=['ok'=>true,'text'=>'Изменения сохранены на сервере.'];
}catch(InvalidArgumentException $e){$_SESSION['MC_PODELU_FLASH']=['ok'=>false,'text'=>$e->getMessage(),'old'=>$p];$success=$return;}
catch(Throwable $e){AddMessage2Log($e->getMessage(),'markitan.podelu');$_SESSION['MC_PODELU_FLASH']=['ok'=>false,'text'=>'Ошибка сохранения. Проверьте миграцию v1.5.0 и журнал Битрикса.','old'=>$p];$success=$return;}
LocalRedirect(V::localUrl($success));
