<?php
/** По делу v1.5.0. Схема v1.4 сохранена. Новые задачи, время и исключения месяцев.
 * Все связанные записи клиента изменяются под блокировкой его строки InnoDB. */
namespace Markitan\Podelu;
if(!defined('B_PROLOG_INCLUDED')||B_PROLOG_INCLUDED!==true){die();}
use Bitrix\Main\Loader;use Bitrix\Main\Application;use Bitrix\Main\Type\DateTime;use Bitrix\Highloadblock\HighloadBlockTable;
require_once __DIR__.'/Policy.php';
final class Repository {
 private $classes=[];
 public const TYPES=[
  'clients'=>['McPodeluClients','mc_podelu_clients'], 'directions'=>['McPodeluDirections','mc_podelu_directions'],
  'packages'=>['McPodeluPackages','mc_podelu_packages'], 'rules'=>['McPodeluPackageRules','mc_podelu_package_rules'],
  'skips'=>['McPodeluPackageSkips','mc_podelu_package_skips'], 'tasks'=>['McPodeluTasks','mc_podelu_tasks'], 'time'=>['McPodeluTime','mc_podelu_time'],
 ];
 public function __construct(){if(!Loader::includeModule('highloadblock'))throw new \RuntimeException('Нет модуля Highload-блоков.');}
 public function table(string $t): string {
  if(isset($this->classes[$t]))return $this->classes[$t];if(!isset(self::TYPES[$t]))throw new \RuntimeException('Неизвестная сущность.');[$name,$table]=self::TYPES[$t];
  $h=HighloadBlockTable::getList(['filter'=>['=NAME'=>$name],'limit'=>1])->fetch();if(!$h||$h['TABLE_NAME']!==$table)throw new \RuntimeException('Не установлена структура '.$name);return $this->classes[$t]=HighloadBlockTable::compileEntity($h)->getDataClass();
 }
 public function ready(): void {foreach(array_keys(self::TYPES) as $t)$this->table($t);if(\Bitrix\Main\Config\Option::get('markitan.podelu','schema_version','')!=='1.5.0')throw new \RuntimeException('Требуется миграция v1.5.0.');}
 public function rows(string $t,array $f=[],array $order=['ID'=>'ASC']): array {$c=$this->table($t);return $c::getList(['filter'=>$f,'order'=>$order])->fetchAll();}
 public function find(string $t,int $id): ?array {if($id<1)return null;$c=$this->table($t);return $c::getByPrimary($id)->fetch()?:null;}
 private function write(string $t,array $v,int $id=0): int {$c=$this->table($t);$r=$id?$c::update($id,$v):$c::add($v);if(!$r->isSuccess())throw new \RuntimeException(implode('; ',$r->getErrorMessages()));return $id?:(int)$r->getId();}
 private function remove(string $t,int $id): void {$c=$this->table($t);$r=$c::delete($id);if(!$r->isSuccess())throw new \RuntimeException(implode('; ',$r->getErrorMessages()));}
 private function stamp(int $u): array {return ['UF_CREATED_AT'=>new DateTime(),'UF_CREATED_BY'=>$u,'UF_XML_ID'=>bin2hex(random_bytes(16))];}
 private function tx(int $client,callable $fn){$this->ready();$c=Application::getConnection();$c->startTransaction();try{$found=$c->query('SELECT ID FROM mc_podelu_clients WHERE ID = '.(int)$client.' FOR UPDATE')->fetch();if(!$found)throw new \InvalidArgumentException('Клиент не найден.');$out=$fn();$c->commitTransaction();return $out;}catch(\Throwable $e){$c->rollbackTransaction();throw $e;}}
 public function addClient(string $name,string $site,string $note,bool $active,int $u): int {return $this->write('clients',['UF_NAME'=>$name,'UF_SITE'=>$site,'UF_COMMENT'=>$note,'UF_ACTIVE'=>$active?1:0]+$this->stamp($u));}
 public function addDirection(string $name): int {foreach($this->rows('directions') as $d)if(mb_strtolower(trim($d['UF_NAME']))===mb_strtolower($name))throw new \InvalidArgumentException('Такое направление уже есть.');return $this->write('directions',['UF_NAME'=>$name,'UF_ACTIVE'=>1,'UF_XML_ID'=>bin2hex(random_bytes(16))]);}
 public static function ids(string $json): array {$v=json_decode($json,true);if(!is_array($v))throw new \RuntimeException('Повреждены направления пакета.');$out=[];foreach($v as $id){if(!is_int($id)||$id<1)throw new \RuntimeException('Некорректный ID направления.');$out[]=$id;}return array_values(array_unique($out));}
 private function dirs(array $ids): void {foreach($ids as $id)if(!$this->find('directions',$id))throw new \InvalidArgumentException('Направление не найдено.');}
 public function packages(int $client,string $m,bool $skipped=false): array {
  $base=$this->rows('packages',['=UF_CLIENT'=>$client]);if(!$base)return [];$ids=array_map(static function($p){return (int)$p['ID'];},$base);$rules=[];foreach($this->rows('rules',['@UF_PACKAGE'=>$ids,'<=UF_MONTH'=>$m]) as $r)$rules[(int)$r['UF_PACKAGE']][]=$r;
  $skips=[];foreach($this->rows('skips',['@UF_PACKAGE'=>$ids,'=UF_MONTH'=>$m]) as $r)$skips[(int)$r['UF_PACKAGE']]=true;$out=[];
  foreach($base as $b){$p=Policy::effective($b,$m,$rules[(int)$b['ID']]??[]);if(!$p)continue;$p['IS_SKIPPED']=isset($skips[(int)$b['ID']]);if($p['IS_SKIPPED']&&!$skipped)continue;$p['DIRECTION_IDS']=self::ids((string)$p['UF_DIRECTION_IDS']);$out[]=$p;}return $out;
 }
 private function effective(int $id,int $client,string $m): ?array {foreach($this->packages($client,$m) as $p)if((int)$p['ID']===$id)return $p;return null;}
 public function entries(string $m='',int $client=0,int $task=0): array {$f=[];if($m!==''){$f['>=UF_DATE']=$m.'-01';$f['<=UF_DATE']=$m.'-31';}if($client)$f['=UF_CLIENT']=$client;if($task)$f['=UF_TASK']=$task;return $this->rows('time',$f,['UF_DATE'=>'DESC','ID'=>'DESC']);}
 public function balance(int $client,string $m): array {return Policy::balance($this->packages($client,$m,true),$this->entries($m,$client));}
 private function base(int $id,int $client): array {$b=$this->find('packages',$id);if(!$b||(int)$b['UF_CLIENT']!==$client)throw new \InvalidArgumentException('Пакет другого клиента или удалён.');return $b;}
 private function checkTime(int $id,int $client): void {$months=[];foreach($this->rows('time',['=UF_PACKAGE'=>$id]) as $e){$m=substr($e['UF_DATE'],0,7);if(!array_key_exists($m,$months))$months[$m]=$this->effective($id,$client,$m);$p=$months[$m];if(!$p||!in_array((int)$e['UF_DIRECTION'],$p['DIRECTION_IDS'],true))throw new \InvalidArgumentException('Изменение сделает учтённые работы недействительными. Сначала перенесите или удалите соответствующие записи времени.');}}
 public function savePackage(int $id,int $client,string $m,string $name,int $minutes,array $dirs,bool $repeat,string $end,string $scope,int $u): int {
  $this->dirs($dirs);return $this->tx($client,function()use($id,$client,$m,$name,$minutes,$dirs,$repeat,$end,$scope,$u){
   $v=['UF_NAME'=>$name,'UF_MINUTES'=>$minutes,'UF_DIRECTION_IDS'=>json_encode(array_values($dirs))];if(!$id){if($end!==''&&$end<$m)throw new \InvalidArgumentException('Окончание раньше начала.');return $this->write('packages',$v+['UF_CLIENT'=>$client,'UF_MONTH'=>$m,'UF_REPEAT'=>$repeat?1:0,'UF_END_MONTH'=>$repeat?$end:'']+$this->stamp($u));}
   $b=$this->base($id,$client);if(empty($b['UF_REPEAT'])){if($b['UF_MONTH']!==$m)throw new \InvalidArgumentException('Разовый пакет относится к другому месяцу.');if($repeat&&$end!==''&&$end<$m)throw new \InvalidArgumentException('Окончание раньше начала.');$this->write('packages',$v+['UF_REPEAT'=>$repeat?1:0,'UF_END_MONTH'=>$repeat?$end:''],$id);}
   else {if(!$repeat)throw new \InvalidArgumentException('Для остановки задайте срок, не снимайте повторение.');if(!Policy::effective($b,$m))throw new \InvalidArgumentException('Пакет не действует в этом месяце.');$old=$this->rows('rules',['=UF_PACKAGE'=>$id,'=UF_MONTH'=>$m,'=UF_SCOPE'=>$scope],['ID'=>'DESC']);$this->write('rules',$v+['UF_PACKAGE'=>$id,'UF_MONTH'=>$m,'UF_SCOPE'=>$scope,'UF_CREATED_AT'=>new DateTime(),'UF_CREATED_BY'=>$u],$old?(int)$old[0]['ID']:0);if($scope==='from')foreach($this->rows('rules',['=UF_PACKAGE'=>$id,'=UF_MONTH'=>$m,'=UF_SCOPE'=>'one']) as $r)$this->remove('rules',(int)$r['ID']);}
   $this->checkTime($id,$client);return $id;
  });
 }
 public function end(int $id,int $client,string $end): int {return $this->tx($client,function()use($id,$client,$end){$b=$this->base($id,$client);if(empty($b['UF_REPEAT']))throw new \InvalidArgumentException('Это разовый пакет.');if($end!==''&&$end<$b['UF_MONTH'])throw new \InvalidArgumentException('Окончание раньше начала.');$this->write('packages',['UF_END_MONTH'=>$end],$id);$this->checkTime($id,$client);return $id;});}
 public function manage(int $id,int $client,string $m,string $mode): int {
  if($mode==='finish')return $this->end($id,$client,$m);
  return $this->tx($client,function()use($id,$client,$m,$mode){$b=$this->base($id,$client);
   if($mode==='delete'){if($this->rows('time',['=UF_PACKAGE'=>$id]))throw new \InvalidArgumentException('В пакете есть записи времени. Перенесите или удалите их либо завершите пакет.');foreach(['rules','skips'] as $t)foreach($this->rows($t,['=UF_PACKAGE'=>$id]) as $r)$this->remove($t,(int)$r['ID']);$this->remove('packages',$id);return $id;}
   if($mode==='clear'){foreach($this->rows('rules',['=UF_PACKAGE'=>$id,'=UF_MONTH'=>$m,'=UF_SCOPE'=>'one']) as $r)$this->remove('rules',(int)$r['ID']);}
   else {if(!Policy::effective($b,$m))throw new \InvalidArgumentException('Пакет не действует в месяце.');$rows=$this->rows('skips',['=UF_PACKAGE'=>$id,'=UF_MONTH'=>$m]);if($mode==='skip'&&!$rows)$this->write('skips',['UF_PACKAGE'=>$id,'UF_MONTH'=>$m]);if($mode==='restore')foreach($rows as $r)$this->remove('skips',(int)$r['ID']);}
   $this->checkTime($id,$client);return $id;
  });
 }
 public function saveTask(int $id,int $client,string $name,string $desc,string $note,int $direction,string $status,string $m,int $u): int {
  $this->dirs([$direction]);return $this->tx($client,function()use($id,$client,$name,$desc,$note,$direction,$status,$m,$u){$old=$id?$this->find('tasks',$id):null;if($id&&(!$old||(int)$old['UF_CLIENT']!==$client))throw new \InvalidArgumentException('Задача другого клиента.');if($old&&(int)$old['UF_DIRECTION']!==$direction&&$this->rows('time',['=UF_TASK'=>$id]))throw new \InvalidArgumentException('Направление задачи с записями времени менять нельзя.');$done=$status==='done'?($old&&$old['UF_STATUS']==='done'?(string)$old['UF_DONE_MONTH']:date('Y-m')):'';$v=['UF_CLIENT'=>$client,'UF_NAME'=>$name,'UF_DESCRIPTION'=>$desc,'UF_NOTE'=>$note,'UF_DIRECTION'=>$direction,'UF_STATUS'=>$status,'UF_MONTH'=>$m,'UF_DONE_MONTH'=>$done];if(!$id)$v+=$this->stamp($u);return $this->write('tasks',$v,$id);});
 }
 public function deleteTask(int $id,int $client): int {return $this->tx($client,function()use($id,$client){$t=$this->find('tasks',$id);if(!$t||(int)$t['UF_CLIENT']!==$client)throw new \InvalidArgumentException('Задача не найдена.');if($this->rows('time',['=UF_TASK'=>$id]))throw new \InvalidArgumentException('Сначала перенесите или удалите записи времени.');$this->remove('tasks',$id);return $id;});}
 public function saveTime(int $id,int $client,int $task,int $package,string $date,int $minutes,string $desc,int $u,string $request): int {
  return $this->tx($client,function()use($id,$client,$task,$package,$date,$minutes,$desc,$u,$request){$old=$id?$this->find('time',$id):null;if($id&&(!$old||(int)$old['UF_CLIENT']!==$client))throw new \InvalidArgumentException('Запись другого клиента.');$t=$this->find('tasks',$task);if(!$t||(int)$t['UF_CLIENT']!==$client)throw new \InvalidArgumentException('Задача другого клиента.');
   $v=['UF_CLIENT'=>$client,'UF_TASK'=>$task,'UF_DIRECTION'=>(int)$t['UF_DIRECTION'],'UF_PACKAGE'=>$package,'UF_DATE'=>$date,'UF_MINUTES'=>$minutes,'UF_DESCRIPTION'=>$desc];
   if(!$id){$key='TIME_'.$request;$same=$this->rows('time',['=UF_CLIENT'=>$client,'=UF_XML_ID'=>$key]);if($same){foreach($v as $f=>$value)if((string)$same[0][$f]!==(string)$value)throw new \InvalidArgumentException('Запрос уже сохранён с другими данными. Обновите список.');return (int)$same[0]['ID'];}}
   if($package){$p=$this->effective($package,$client,substr($date,0,7));if(!$p||!in_array((int)$t['UF_DIRECTION'],$p['DIRECTION_IDS'],true))throw new \InvalidArgumentException('Пакет не подходит для клиента, даты или направления работы.');}
   if(!$id){$stamp=$this->stamp($u);$stamp['UF_XML_ID']='TIME_'.$request;$v+=$stamp;}return $this->write('time',$v,$id);
  });
 }
 public function deleteTime(int $id,int $client): int {return $this->tx($client,function()use($id,$client){$e=$this->find('time',$id);if(!$e||(int)$e['UF_CLIENT']!==$client)throw new \InvalidArgumentException('Запись не найдена.');$this->remove('time',$id);return $id;});}
}
