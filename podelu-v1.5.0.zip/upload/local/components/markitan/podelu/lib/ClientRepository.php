<?php
/** По делу v1.5.0. Адаптер прежнего репозитория. */
namespace Markitan\Podelu;
if(!defined('B_PROLOG_INCLUDED')||B_PROLOG_INCLUDED!==true){die();}require_once __DIR__.'/Repository.php';
final class ClientRepository {
 public const BLOCK_NAME='McPodeluClients';public const TABLE_NAME='mc_podelu_clients';private $r;
 public function __construct(){$this->r=new Repository();}public function find(int $id): ?array{return $this->r->find('clients',$id);}public function add(string $n,string $s,string $c,bool $a,int $u): int{return $this->r->addClient($n,$s,$c,$a,$u);}
 public function stats(): array {$all=$this->r->rows('clients');return ['total'=>count($all),'active'=>count(array_filter($all,static function($c){return !empty($c['UF_ACTIVE']);}))];}
 public function list(string $q,int $p,int $size=20): array {$a=$this->r->rows('clients',$q!==''?['%UF_NAME'=>$q]:[],['UF_NAME'=>'ASC']);$n=count($a);$pages=max(1,(int)ceil($n/$size));$p=min(max(1,$p),$pages);return ['rows'=>array_slice($a,($p-1)*$size,$size),'count'=>$n,'page'=>$p,'pages'=>$pages];}
}
