<?php
/** По делу v1.5.0. Политика v1.4: база -> from -> one; без переноса часов. */
namespace Markitan\Podelu;
final class Policy {
 public static function effective(array $b,string $m,array $rules=[]): ?array {
  $repeat=!empty($b['UF_REPEAT']);$start=(string)$b['UF_MONTH'];$end=(string)($b['UF_END_MONTH']??'');
  if((!$repeat&&$m!==$start)||($repeat&&($m<$start||($end!==''&&$m>$end))))return null;
  $out=$b;$out['VIEW_MONTH']=$m;$out['RULE_SOURCE']='base';$out['RULE_MONTH']=$start;$out['HAS_MONTH_OVERRIDE']=false;
  if(!$repeat)return $out;usort($rules,static function($a,$b){return strcmp($a['UF_MONTH'],$b['UF_MONTH'])?:((int)$a['ID']<=>(int)$b['ID']);});$one=null;
  foreach($rules as $r){if((int)$r['UF_PACKAGE']!==(int)$b['ID']||$r['UF_MONTH']<$start)continue;
   if($r['UF_SCOPE']==='from'&&$r['UF_MONTH']<=$m){foreach(['UF_NAME','UF_MINUTES','UF_DIRECTION_IDS'] as $f)$out[$f]=$r[$f];$out['RULE_SOURCE']='from';$out['RULE_MONTH']=$r['UF_MONTH'];}
   if($r['UF_SCOPE']==='one'&&$r['UF_MONTH']===$m)$one=$r;
  }
  if($one){foreach(['UF_NAME','UF_MINUTES','UF_DIRECTION_IDS'] as $f)$out[$f]=$one[$f];$out['RULE_SOURCE']='one';$out['RULE_MONTH']=$m;$out['HAS_MONTH_OVERRIDE']=true;}return $out;
 }
 public static function balance(array $ps,array $entries): array {
  $by=[];$spent=0;$extra=0;foreach($entries as $e){$n=(int)$e['UF_MINUTES'];$spent+=$n;$id=(int)$e['UF_PACKAGE'];if($id)$by[$id]=($by[$id]??0)+$n;else $extra+=$n;}
  $limit=0;$free=0;$over=0;$count=0;foreach($ps as &$p){$p['SPENT']=$by[(int)$p['ID']]??0;$p['REST']=!empty($p['IS_SKIPPED'])?0:(int)$p['UF_MINUTES']-$p['SPENT'];if(empty($p['IS_SKIPPED'])){++$count;$limit+=(int)$p['UF_MINUTES'];$free+=max(0,$p['REST']);$over+=max(0,-$p['REST']);}}unset($p);
  return ['packages'=>$ps,'limit'=>$limit,'spent'=>$spent,'extra'=>$extra,'packageSpent'=>$spent-$extra,'free'=>$free,'over'=>$over,'count'=>$count];
 }
}
