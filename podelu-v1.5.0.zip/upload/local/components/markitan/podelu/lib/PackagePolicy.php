<?php
/** По делу v1.5.0. Совместимый класс v1.4.0. */
namespace Markitan\Podelu;require_once __DIR__.'/Policy.php';
final class PackagePolicy {public static function effective(array $b,string $m,array $rules=[]): ?array {return Policy::effective($b,$m,$rules);}}
