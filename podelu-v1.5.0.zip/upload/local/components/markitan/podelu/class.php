<?php
/** По делу v1.5.0. Отдельные страницы; запись вынесена в защищённый POST/PRG-обработчик. */
if(!defined('B_PROLOG_INCLUDED')||B_PROLOG_INCLUDED!==true){die();}
require_once __DIR__.'/lib/Repository.php';require_once __DIR__.'/lib/Validation.php';
class MarkitanPodeluComponent extends CBitrixComponent {
 public function executeComponent(){global $USER;$res=\Bitrix\Main\Context::getCurrent()->getResponse();$res->addHeader('Cache-Control','no-store, private');$res->addHeader('X-Content-Type-Options','nosniff');$this->arResult=['ALLOWED'=>$USER->IsAuthorized()&&$USER->IsAdmin(),'ERROR'=>''];
  if(!$this->arResult['ALLOWED']){$res->setStatus('403 Forbidden');$this->includeComponentTemplate();return;}
  try{$r=new \Markitan\Podelu\Repository();$r->ready();$this->arResult['R']=$r;$this->arResult['VIEW']=$this->arParams['VIEW']??'clients';$this->arResult['LEGACY']=!empty($this->arParams['LEGACY']);}
  catch(Throwable $e){AddMessage2Log($e->getMessage(),'markitan.podelu');$this->arResult['ERROR']='Нужна миграция v1.5.0 или проверка журнала ошибок. Существующие данные не очищаются.';}
  ob_start();try{$this->includeComponentTemplate();$html=ob_get_clean();echo $html;}catch(Throwable $e){ob_end_clean();AddMessage2Log($e->getMessage(),'markitan.podelu.view');echo '<main class="paper gate"><h1>Не удалось открыть страницу</h1><p>Проверьте миграцию и журнал Битрикса. Клиентские данные не удалялись.</p><a href="/clients/">Клиенты</a></main>';}
 }
}
