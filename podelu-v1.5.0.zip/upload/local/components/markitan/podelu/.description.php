<?php
/** По делу v1.5.0. */
if(!defined('B_PROLOG_INCLUDED')||B_PROLOG_INCLUDED!==true){die();}
$arComponentDescription=['NAME'=>'По делу: кабинет','DESCRIPTION'=>'v1.5.0: задачи и время','PATH'=>['ID'=>'markitan','NAME'=>'Markitan Concept']];
