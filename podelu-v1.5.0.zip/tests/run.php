<?php
/** По делу v1.5.0. Чистые CLI-тесты, не требуют Битрикса и БД. */
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
require __DIR__.'/../upload/local/components/markitan/podelu/lib/Policy.php';require __DIR__.'/../upload/local/components/markitan/podelu/lib/Validation.php';
use Markitan\Podelu\Policy;use Markitan\Podelu\Validation as V;
$n=0;function same($e,$a,$name){global $n;if($e!==$a){fwrite(STDERR,'FAIL '.$name.': '.var_export($a,true).PHP_EOL);exit(1);}++$n;}
$b=['ID'=>8,'UF_MONTH'=>'2026-11','UF_REPEAT'=>1,'UF_END_MONTH'=>'','UF_NAME'=>'Поддержка','UF_MINUTES'=>600,'UF_DIRECTION_IDS'=>'[1,2]'];
$rule=static function($id,$m,$s,$min){return ['ID'=>$id,'UF_PACKAGE'=>8,'UF_MONTH'=>$m,'UF_SCOPE'=>$s,'UF_NAME'=>'Условия','UF_MINUTES'=>$min,'UF_DIRECTION_IDS'=>'[1,2]'];};
same(null,Policy::effective($b,'2026-10'),'before');same(600,(int)Policy::effective($b,'2026-12')['UF_MINUTES'],'monthly');
$r=[$rule(1,'2026-12','one',900),$rule(2,'2027-01','from',1200)];
same(900,(int)Policy::effective($b,'2026-12',$r)['UF_MINUTES'],'one');same(600,(int)Policy::effective($b,'2026-11',$r)['UF_MINUTES'],'past');same(1200,(int)Policy::effective($b,'2027-02',$r)['UF_MINUTES'],'from');
$ended=$b;$ended['UF_END_MONTH']='2026-12';same(600,(int)Policy::effective($ended,'2026-12')['UF_MINUTES'],'inclusive');same(null,Policy::effective($ended,'2027-01'),'end');
$old=$b;unset($old['UF_REPEAT']);same(600,(int)Policy::effective($old,'2026-11')['UF_MINUTES'],'old');same(null,Policy::effective($old,'2026-12'),'old not recurring');
$ps=[['ID'=>1,'UF_MINUTES'=>600,'IS_SKIPPED'=>false],['ID'=>2,'UF_MINUTES'=>300,'IS_SKIPPED'=>false],['ID'=>3,'UF_MINUTES'=>240,'IS_SKIPPED'=>true]];
$e=[['UF_PACKAGE'=>1,'UF_MINUTES'=>690],['UF_PACKAGE'=>2,'UF_MINUTES'=>60],['UF_PACKAGE'=>0,'UF_MINUTES'=>120]];$a=Policy::balance($ps,$e);
same(900,$a['limit'],'allocated');same(870,$a['spent'],'spent');same(750,$a['packageSpent'],'package');same(120,$a['extra'],'extra');same(240,$a['free'],'positive');same(90,$a['over'],'overrun');same(2,$a['count'],'count');same(-90,$a['packages'][0]['REST'],'negative');same(900,Policy::balance($ps,[])['free'],'delete time returns hours');
$shared=Policy::balance([['ID'=>1,'UF_MINUTES'=>600,'IS_SKIPPED'=>false]],[['UF_PACKAGE'=>1,'UF_MINUTES'=>90],['UF_PACKAGE'=>1,'UF_MINUTES'=>30]]);same(480,$shared['free'],'shared');
same(90,V::minutes('1.5',true),'minutes');same(15,V::minutes('0,25',true),'comma');same('2028-02-29',V::date('2028-02-29'),'leap');
same('/clients/',V::localUrl('https://example.org'),'external redirect');same('/clients/',V::localUrl('//example.org'),'protocol redirect');same('/clients/',V::localUrl('/unknown'),'path redirect');same('/works/?month=2026-11',V::localUrl('/works/?month=2026-11'),'local redirect');
try{V::date('2026-02-29');same(true,false,'invalid date accepted');}catch(InvalidArgumentException $e){same(true,true,'bad date rejected');}
try{V::minutes('1.1',true);same(true,false,'bad step accepted');}catch(InvalidArgumentException $e){same(true,true,'bad step rejected');}
echo 'PASS: '.$n.' checks'.PHP_EOL;
